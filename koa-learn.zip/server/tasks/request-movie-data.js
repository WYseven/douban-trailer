const rpn = require('request-promise-native');  // request的promise形式

// 根据电影id获取电影的具体信息
async function getMovieData(movieId) {
  let url = `http://api.douban.com/v2/movie/subject/${movieId}`;
  return await rpn(url)
}

// 自动开始获取
; (async () => {
  let movies = [{
    movieId: 4942778
  },
  {
    movieId: 25858785
  }];

  movies.map(async (item) => {
    let movieData = await getMovieData(item.movieId);

    // 解析数据,可能会出错
    try {
      movieData = JSON.parse(movieData)
    } catch (err) {
      console.log(err);
    }

    // 打印拿到数据
    console.log(movieData)

  })

})()