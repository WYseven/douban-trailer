const mongoose = require('mongoose');
const { database, mongodUrl } = require('./config');  //获取配置的json文件

mongoose.Promise = global.Promise;

let db = mongodUrl + database

export const connect = async ()=> {
  if(process.env.NODE_ENV !== 'production'){  // 不是生产环境，则开启调试
    mongoose.set('debug',true);
  }
  
  return new Promise((resolve,reject) => {

    mongoose.connect(db);

    mongoose.connection.on('disconnected', (error) => {
      reject(error)
    })
    mongoose.connection.on('error', (err) => {
      reject(err)
    })
    mongoose.connection.once('open', resolve)
  })
}