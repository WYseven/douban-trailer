module.exports = {
  qiniu: {
    visitUrl: 'http://p541db6x5.bkt.clouddn.com/',
    bucket: 'douban-img-video-pub',
    AK:'FpdQBOsIZsQzK_QEJ1LFxhY2LrYwVNKd_rMnmEHS',
    SK: 'LzKEKazAjPv1dIflx8BdZtagx22c7n0O7U4LpSDy'
  }
}